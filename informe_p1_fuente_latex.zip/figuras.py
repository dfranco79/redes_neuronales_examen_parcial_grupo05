"""Genera las figuras del informe a partir de las salidas de Colab."""
import json, glob, numpy as np, pandas as pd, cv2
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt

TINTA, TINTA2, REJILLA = '#0b0b0b', '#52514e', '#e4e3df'
SERIES = ['#2a78d6', '#eb6834', '#1baf7a', '#eda100', '#8a5cd6']
plt.rcParams.update({'font.family': 'serif', 'font.serif': ['Times New Roman', 'Times', 'DejaVu Serif'],
                     'font.size': 9, 'axes.edgecolor': TINTA2, 'axes.labelcolor': TINTA, 'xtick.color': TINTA2,
                     'ytick.color': TINTA2, 'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.grid': True, 'grid.color': REJILLA, 'grid.linewidth': 0.6, 'savefig.dpi': 220})
R = 'res_new/salidas/'
ET = ["ACL","MCL","Medial Meniscus","Lateral Meniscus","Medial OA","Lateral OA","PF OA","Effusion","Synovitis","Baker's","Contusion","Fracture"]
ES = ["LCA","LCM","Menisco medial","Menisco lateral","OA medial","OA lateral","OA patelofemoral","Derrame","Sinovitis","Quiste de Baker","Contusión","Fractura"]

def hist(exp):
    return pd.DataFrame(json.load(open(R + exp + '/resumen.json'))['historial'])

# --- Figura: curvas de AUC en validación débil
fig, ejes = plt.subplots(1, 2, figsize=(7.2, 2.6), sharey=True)
grupos = [[('cero_bce_suave_ninguno_principal', 'CNN desde cero'), ('resnet50_bce_suave_ninguno_principal', 'ResNet-50 (BCE)')],
          [('resnet50_bce_suave_ninguno_principal', 'BCE'), ('resnet50_focal_suave_ninguno_principal', 'Focal'),
           ('resnet50_bce_consenso_ninguno_principal', 'Consenso'), ('resnet50_bce_suave_pos_weight_principal', 'pos_weight'), ('resnet50_bce_suave_ninguno_alterna', 'Coronal')]]
for ax, g, tit in zip(ejes, grupos, ['(a) Arquitecturas', '(b) Ablaciones sobre ResNet-50']):
    for (exp, nom), c in zip(g, SERIES):
        h = hist(exp)
        ax.plot(h.epoca, h.auc_validacion_debil, color=c, lw=2, label=nom)
        ax.scatter(h.epoca.iloc[h.auc_validacion_debil.idxmax()], h.auc_validacion_debil.max(), s=22, color=c, edgecolor='white', zorder=3)
    ax.set_title(tit, fontsize=9, color=TINTA, loc='left'); ax.set_xlabel('Época')
    ax.legend(frameon=False, fontsize=7.5, loc='lower right' if 'Abl' in tit else 'upper left')
ejes[0].set_ylabel('AUC macro (validación débil)')
fig.tight_layout(); fig.savefig('fig/curvas.pdf'); plt.close(fig)

# --- Figura: AUC por etiqueta, cero vs ResNet-50
m0 = pd.read_csv(R + 'cero_bce_suave_ninguno_principal/metricas_oro.csv').set_index('etiqueta')
m1 = pd.read_csv(R + 'resnet50_bce_suave_ninguno_principal/metricas_oro.csv').set_index('etiqueta')
y = np.arange(len(ET)); h = 0.38
fig, ax = plt.subplots(figsize=(6.4, 3.3))
ax.barh(y - h/2 - 0.01, m0.loc[ET, 'auc_roc'], h, color=SERIES[0], label='CNN desde cero')
ax.barh(y + h/2 + 0.01, m1.loc[ET, 'auc_roc'], h, color=SERIES[1], label='ResNet-50 (BCE)')
ax.axvline(0.5, color=TINTA2, lw=1, ls='--'); ax.text(0.505, -1.05, 'azar', color=TINTA2, fontsize=7)
ax.set_yticks(y, ES); ax.invert_yaxis(); ax.set_xlim(0.4, 1.0); ax.set_xlabel('AUC-ROC sobre el conjunto dorado (n = 53)')
ax.grid(axis='y', visible=False); ax.legend(frameon=False, fontsize=7.5, loc='lower right')
fig.tight_layout(); fig.savefig('fig/auc_etiqueta.pdf'); plt.close(fig)

# --- Figura: prevalencia entrenamiento vs oro
prev = pd.read_csv(R + 'prevalencia_seleccion.csv', index_col=0)
p_ent = 100 * prev['entrenamiento'] / 425
# prevalencia dorada sobre los 53 estudios realmente evaluados con imagen
ids = pd.read_csv(R + 'resnet50_bce_suave_ninguno_principal/predicciones_oro.csv').StudyInstanceUID
oro = pd.read_csv('/home/claude/p1/datos/train.csv').set_index('StudyInstanceUID').loc[ids, ET]
p_oro = 100 * oro.mean()
fig, ax = plt.subplots(figsize=(6.4, 3.0))
ax.barh(y - h/2 - 0.01, p_ent.loc[ET], h, color=SERIES[0], label='Entrenamiento (etiqueta débil, n = 425)')
ax.barh(y + h/2 + 0.01, p_oro.loc[ET], h, color=SERIES[2], label=f'Dorado (n = {len(oro)})')
ax.set_yticks(y, ES); ax.invert_yaxis(); ax.set_xlabel('Prevalencia (%)'); ax.grid(axis='y', visible=False)
ax.legend(frameon=False, fontsize=7.5, loc='upper center', bbox_to_anchor=(0.5, 1.12), ncol=2)
fig.tight_layout(); fig.savefig('fig/prevalencia.pdf'); plt.close(fig)

# --- Figura: ejemplo de volumen preprocesado (cortes sagitales)
v = np.load(glob.glob('/tmp/claude-0/prueba_tensores/*.npz')[0])['volumen']
fig, ax = plt.subplots(1, 5, figsize=(7.2, 1.6))
for a, k in zip(ax, [2, 7, 12, 17, 21]):
    a.imshow(v[k], cmap='gray'); a.set_title(f'corte {k}', fontsize=7.5, color=TINTA2); a.axis('off')
fig.tight_layout(pad=0.2); fig.savefig('fig/cortes.pdf'); plt.close(fig)

# --- Figura: Grad-CAM (ResNet-50 y CNN desde cero)
def panel(rutas, salida, rotulos):
    ims = []
    for r, t in zip(rutas, rotulos):
        im = cv2.imread(r); im = cv2.resize(im, (448, 224))
        ims.append((cv2.cvtColor(im, cv2.COLOR_BGR2RGB), t))
    fig, ax = plt.subplots(1, len(ims), figsize=(7.2, 1.95))
    for a, (im, t) in zip(ax, ims):
        a.imshow(im); a.set_title(t, fontsize=7.5, color=TINTA); a.axis('off')
    fig.tight_layout(pad=0.3); fig.savefig(salida); plt.close(fig)
g1 = R + 'resnet50_bce_suave_ninguno_principal/gradcam/'
panel([g1 + 'ACL_68367236_p0.84_corte4.png', g1 + 'Medial_Meniscus_29200903_p0.89_corte5.png',
       g1 + 'Effusion_63784327_p0.99_corte5.png', g1 + "Baker's_07169581_p0.53_corte5.png"],
      'fig/gradcam_resnet.pdf', ['(a) LCA, p = 0,84', '(b) Menisco medial, p = 0,89', '(c) Derrame, p = 0,99', '(d) Baker, p = 0,53'])
g0 = R + 'cero_bce_suave_ninguno_principal/gradcam/'
panel([g0 + "Baker's_07169581_p0.35_corte6.png", g0 + "Baker's_21482192_p0.37_corte2.png",
       g0 + 'ACL_53941774_p0.32_corte6.png', g0 + 'Effusion_07169581_p0.81_corte6.png'],
      'fig/gradcam_cero.pdf', ['(a) Baker, p = 0,35', '(b) Baker, p = 0,37', '(c) LCA, p = 0,32', '(d) Derrame, p = 0,81'])
print('ok')
